/** Automatically generated file. DO NOT MODIFY */
package com.example.eztunes;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}